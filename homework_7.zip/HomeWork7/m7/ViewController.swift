//
//  ViewController.swift
//  m7
//
//  Created by Maxim Nikolaev on 11.07.2021.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var header: UILabel!
    @IBOutlet weak var button: UIButton!
    var clickCounter: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        setupHeader(clickCounter)
    }

    @IBAction func onButtonPressed(_ sender: Any) {
        clickCounter += 1
        setupHeader(clickCounter)
    }
    
    func setupHeader(_ clicker: Int) {
        header.text = "Нажатий: \(clicker)"
    }
}

